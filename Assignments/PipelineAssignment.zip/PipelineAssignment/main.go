package main

import "hotelapp/server"

func main() {
	server.GetHotels()
}
